﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace ColorMixer.ViewModel
{
    public partial class RGBEllipse : ObservableObject
    {

        [ObservableProperty]
        private byte red;
        
        [ObservableProperty]
        private string color = "#000000";
        
        [ObservableProperty]
        private byte green;

        [ObservableProperty]
        private byte blue;

        [ObservableProperty]
        private string hexInput;

        partial void OnBlueChanged(byte value)
        {
            CalculateColorFromRGB();
        }
        partial void OnRedChanged(byte value)
        {
            CalculateColorFromRGB();
        }
        partial void OnGreenChanged(byte value)
        {
            CalculateColorFromRGB();
        }


        private dynamic ParseToHex (int start, int length)
        {
            var result = byte.Parse(this.Color.Substring(start, length), System.Globalization.NumberStyles.HexNumber);
            return result;
        }
        private void CalculateRGBFromColor ()
        {
            (this.Red, this.Green, this.Blue) = (ParseToHex(1, 2), ParseToHex(3, 2), ParseToHex(5, 2));
        }
        private void CalculateColorFromRGB ()
        {

            this.Color = $"#{this.Red:X2}{this.Green:X2}{this.Blue:X2}";
            this.HexInput = this.Color;
        }
        partial void OnHexInputChanged(string value)
        {
            if (!Regex.IsMatch(value, @"^#[\dA-F]{6}$", RegexOptions.IgnoreCase))
            {
                return;
            }
            this.Color = HexInput;
            CalculateRGBFromColor();

        }



    }
    
}
